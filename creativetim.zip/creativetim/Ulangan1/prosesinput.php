<?php

include 'koneksi.php';

$nama= $_POST['nama'];
$email= $_POST['email'];
$no_telp= $_POST['no_telp'];
$pekerjaan= $_POST['pekerjaan'];



 mysqli_query($dbconnect, "INSERT INTO kontak VALUES ( NULL, '$nama','$email','$no_telp','$pekerjaan')");

 header("location:user.php")
 ?>