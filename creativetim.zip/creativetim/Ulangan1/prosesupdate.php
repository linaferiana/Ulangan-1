<?php

 include 'koneksi.php';
  $id= $_POST['id'];
  $nama= $_POST['nama'];
  $email= $_POST['email'];
  $notelp= $_POST['no_telp'];
  $pekerjaan= $_POST['pekerjaan'];
  



  mysqli_query($dbconnect, "UPDATE `kontak` SET `nama`='$nama' , `email`='$email' , `no_telp`='$notelp' , `pekerjaan`='$pekerjaan' WHERE `id`='$id' ");
  header("location:user.php");
  ?>